package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwaggerCommonUiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SwaggerCommonUiApplication.class, args);
	}

}
